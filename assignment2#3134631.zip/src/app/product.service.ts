import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products = [
    { name: 'mobile', price: 2100, category: 'Electric' },
    { name: 'car', price: 4500, category: 'automobile' },
    { name: ' laptop', price: 800, category: 'eltronic' }, 
  ];

  getProducts() {
    return this.products;
  }
}
